<!DOCTYPE html>
<html>
<head>
    <title>Maxsilog Fud Haus Attendance and Payroll System</title>
    <meta name="viewport" content="width=device-width">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/all.css">
    <link rel="stylesheet" type="text/css" href="css/all.min.css">
    <link rel="stylesheet" type="text/css" href="css/lightbox.css">
    <link rel="stylesheet" type="text/css" href="css/flexslider.css">
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
    <link rel="stylesheet" type="text/css" href="css/owl.theme.default.css">
    <link rel="stylesheet" type="text/css" href="css/jquery.rateyo.css"/>
   
    <link rel="stylesheet" type="text/css" href="inner-page-style.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,700" rel="stylesheet">
</head>
<body>
    <div id="page" class="site" itemscope itemtype="http://schema.org/LocalBusiness">
        <header class="site-header">
            <div class="main-header">
                <div class="container">
                    <div class="logo-wrap" itemprop="logo">
                        <img src="images/maxsilogo.jpg" alt="Logo Image">
                    </div>
                    <div class="nav-wrap">
                        <nav class="nav-desktop">
                            <ul class="menu-list">
                                <li><a href="index.php">Employee Login</a></li>
                                <li><a href="index.php">Admin Login</a></li>


                            </ul>
                        </nav>
            </div>
        </header>
        <!-- Header Close -->
        <div class="banner">
            <div class="owl-four owl-carousel" itemprop="image">
                <img src="images/wall.jpg">
                <img src="images/paper.jpg">
            </div>
            <div class="container" itemprop="description">
                <h1>Most affordable tapsihan in the heart of Pineda, Pasig</h1>
            </div>
             <div id="owl-four-nav" class="owl-nav"></div>
        </div>
        
        <!-- Banner Close -->
        <div class="page-heading">
            <div class="container">
                <h2>Popular Maxsi Menu</h2>
            </div>
        </div>
        <!-- Popular Food -->
        <div class="learn-courses">
            <div class="container">
                <div class="courses">
                    <div class="owl-one owl-carousel">
                        <div class="box-wrap" itemprop="event" itemscope itemtype=" http://schema.org/Course">
                            <div class="img-wrap" itemprop="image"><img src="images/Tapasilog.jpg"></div>
                            <div class="box-body" itemprop="description">
                                <p>Maxsilog Beef Tapa, Sunny-Side up egg, Java Rice, and Mixed Veggies</p>
                            </div>
                        </div>

                        <div class="box-wrap" itemprop="event" itemscope itemtype=" http://schema.org/Course">
                            <div class="img-wrap"  itemprop="image"><img src="images/Hamsilog.jpg"></div>
                            <div class="box-body" itemprop="description">
                                <p>Sweet Ham, Sunny-Side up egg, Java Rice, and Mixed Veggies</p>
                            </div>
                        </div>

                        <div class="box-wrap" itemprop="event" itemscope itemtype=" http://schema.org/Course">
                            <div class="img-wrap"  itemprop="image"><img src="images/Chixilog.jpg"></div>
                            <div class="box-body" itemprop="description">
                                <p>Signature Chicken, Sunny-Side up egg, Java Rice, and Mixed Veggies</p>
                            </div>
                        </div>

                        <div class="box-wrap" itemprop="event" itemscope itemtype=" http://schema.org/Course">
                            <div class="img-wrap"  itemprop="image"><img src="images/Longsilog.jpg"></div>
                            <div class="box-body" itemprop="description">
                                <p>Savory Longganisa, Sunny-Side up egg, Java Rice, and Mixed Veggies</p>
                            </div>
                        </div>

                        <div class="box-wrap" itemprop="event" itemscope itemtype=" http://schema.org/Course">
                            <div class="img-wrap"  itemprop="image"><img src="images/Tosilog.jpg"></div>
                            <div class="box-body" itemprop="description">
                                <p>Homemade Tocino, Sunny-Side up egg, Java Rice, and Mixed Veggies</p>
                            </div>
                        </div>

                        <div class="box-wrap" itemprop="event" itemscope itemtype=" http://schema.org/Course">
                            <div class="img-wrap"  itemprop="image"><img src="images/Porksilog.jpg"></div>
                            <div class="box-body" itemprop="description">
                                <p>Flavorful Porkchop, Sunny-Side up egg, Java Rice, and Mixed Veggies</p>
                            </div>
                        </div>

                        <div class="box-wrap" itemprop="event" itemscope itemtype=" http://schema.org/Course">
                            <div class="img-wrap"  itemprop="image"><img src="images/Liemposilog.jpg"></div>
                            <div class="box-body" itemprop="description">
                                <p>Juicy Liempo, Sunny-Side up egg, Java Rice, and Mixed Veggies</p>
                            </div>
                        </div>

                        <div class="box-wrap" itemprop="event" itemscope itemtype=" http://schema.org/Course">
                            <div class="img-wrap"  itemprop="image"><img src="images/Burger Steak.jpg"></div>
                            <div class="box-body" itemprop="description">
                                <p>Classic Burger Patties, Mushroom Gravy, White Rice, and Mixed Veggies</p>
                            </div>
                        </div>

                        <div class="box-wrap" itemprop="event" itemscope itemtype=" http://schema.org/Course">
                            <div class="img-wrap"  itemprop="image"><img src="images/Beef.jpg"></div>
                            <div class="box-body" itemprop="description">
                                <p>Hearty Beef, Mushroom Gravy with White Onions, White Rice, and Mixed Veggies</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Footer Section -->
        <footer class="page-footer" itemprop="footer">
            <div class="footer-first-section">
                <div class="container">
                    <div class="box-wrap" itemprop="about">
                        <header>
                            <h1>about & contact us</h1>
                        </header>
                        <p>Most affordable tapsihan in the heart of Pineda, Pasig</p>
                        <h4><a href=""><i class="fas fa-map-marker-alt"></i>Pineda, Pasig City</a></h4>
                    </div>

            <div class="footer-last-section">
                <div class="container">
                    <p><a href="tel:+277440464"><i class="fas fa-phone"></i> 277440464</a> <span> | </span> <a href="https://www.facebook.com/maxsilog"><i class="fab fa-facebook-square"></i> facebook.com/maxsilog</a></p>
                </div>
            </div>
        </footer>

    </div>
    <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="js/lightbox.js"></script>
    <script type="text/javascript" src="js/all.js"></script>
    <script type="text/javascript" src="js/isotope.pkgd.min.js"></script>
    <script type="text/javascript" src="js/owl.carousel.js"></script>
    <script type="text/javascript" src="js/jquery.flexslider.js"></script>
    <script type="text/javascript" src="js/jquery.rateyo.js"></script>
   
    <script type="text/javascript" src="js/custom.js"></script>
</body>
</html>